# Simple Survey Bot

A Pen created on CodePen.io. Original URL: [https://codepen.io/Karthika-Raj/pen/VwRJLyE](https://codepen.io/Karthika-Raj/pen/VwRJLyE).

This is a simple js bot made with javascript